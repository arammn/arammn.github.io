import Navbar from "@/components/Navbar";
import ProductCard from "@/components/ProductCard";

const products = [
  {
    id: 1,
    name: "Лавандовый сон",
    price: 1200,
    image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=800",
    description: "Успокаивающий аромат лаванды для безмятежного отдыха",
  },
  {
    id: 2,
    name: "Ванильное облако",
    price: 1400,
    image: "https://images.unsplash.com/photo-1602874801007-bd36c376cd00?w=800",
    description: "Теплый и уютный аромат ванили для создания особой атмосферы",
  },
  {
    id: 3,
    name: "Морской бриз",
    price: 1300,
    image: "https://images.unsplash.com/photo-1596433809252-901acb55fc63?w=800",
    description: "Свежий аромат моря и прибрежных трав",
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      
      <main>
        {/* Hero Section */}
        <section className="relative h-[70vh] flex items-center justify-center bg-brown text-cream">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: "url('https://images.unsplash.com/photo-1601479604588-68d2f0d94f8d?w=1800')",
              opacity: "0.3",
            }}
          />
          <div className="relative text-center space-y-4 px-4">
            <h1 className="font-playfair text-5xl md:text-6xl">
              Создайте атмосферу уюта
            </h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">
              Откройте для себя коллекцию ароматических свечей ручной работы
            </p>
          </div>
        </section>

        {/* Popular Products */}
        <section className="container py-16">
          <h2 className="font-playfair text-3xl text-brown mb-8 text-center">
            Популярные товары
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </section>

        {/* Features */}
        <section className="bg-brown text-cream py-16">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="space-y-4">
                <h3 className="font-playfair text-xl">Ручная работа</h3>
                <p className="text-cream/80">Каждая свеча создана с любовью и вниманием к деталям</p>
              </div>
              <div className="space-y-4">
                <h3 className="font-playfair text-xl">Натуральные компоненты</h3>
                <p className="text-cream/80">Используем только экологически чистые материалы</p>
              </div>
              <div className="space-y-4">
                <h3 className="font-playfair text-xl">Быстрая доставка</h3>
                <p className="text-cream/80">Доставляем по всей России в течение 1-3 дней</p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Index;