import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";

interface ProductCardProps {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
}

const ProductCard = ({ id, name, price, image, description }: ProductCardProps) => {
  const handleAddToCart = () => {
    toast({
      title: "Товар добавлен в корзину",
      description: `${name} добавлен в вашу корзину`,
    });
  };

  return (
    <div className="group bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300">
      <div className="relative aspect-square overflow-hidden rounded-t-lg">
        <img
          src={image}
          alt={name}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-4">
        <h3 className="font-playfair text-lg text-brown mb-2">{name}</h3>
        <p className="text-sm text-brown/60 mb-4 line-clamp-2">{description}</p>
        <div className="flex items-center justify-between">
          <span className="font-semibold text-brown">{price} ₽</span>
          <Button
            onClick={handleAddToCart}
            className="bg-brown hover:bg-brown-light text-cream"
          >
            В корзину
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;