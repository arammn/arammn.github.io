import { ShoppingCart, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Navbar = () => {
  return (
    <nav className="bg-cream border-b border-brown/10 py-4">
      <div className="container mx-auto flex items-center justify-between">
        <a href="/" className="font-playfair text-2xl text-brown">
          Candle Haven
        </a>
        
        <div className="hidden md:flex items-center space-x-6">
          <a href="/catalog" className="text-brown hover:text-brown-light transition-colors">
            Каталог
          </a>
          <a href="/about" className="text-brown hover:text-brown-light transition-colors">
            О нас
          </a>
          <a href="/contact" className="text-brown hover:text-brown-light transition-colors">
            Контакты
          </a>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative hidden md:block">
            <Input
              type="search"
              placeholder="Поиск..."
              className="w-64 pl-8 bg-white/80"
            />
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-brown/40" />
          </div>
          
          <Button variant="ghost" size="icon" className="relative">
            <ShoppingCart className="h-5 w-5 text-brown" />
            <span className="absolute -top-1 -right-1 bg-gold text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              0
            </span>
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;